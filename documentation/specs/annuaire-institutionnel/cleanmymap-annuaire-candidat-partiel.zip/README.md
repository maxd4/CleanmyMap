# Candidat partiel - Annuaire nominatif

Base observée : cd97f32e9752e151a243fc9b60e2f5f9890508b2. Ne pas imposer ce SHA au checkout local. Les fichiers sont des candidats, pas des changements publiés.

Le module public et les tests prolongent le référentiel existant. Intégrer `integration.patch` et les nouveaux fichiers sous leurs chemins cibles. Contrôler les collisions, les consommateurs de l'union de provenance et le rendu réel. Ne pas déduire une appartenance à une division d'une correspondance géographique. Les faits privés ne sont jamais consommés par le module public.

`relationship-evidence.ts` est le candidat de logique de badges administratifs seulement. Le service serveur doit vérifier les preuves, l'existence des ressources, les dates et les droits avant d'appeler la dérivation. Ne pas accepter les statuts verified ni les preuves déclarés par le navigateur comme autorité. Un récit tiers demeure distinct, même si sa réception est vérifiée. Une contribution doit être réalisée, documentée et vérifiée indépendamment ; une promesse ne suffit pas. Retrait d'une preuve : recalcul des indicateurs, pas de flags persistés séparément.

12 assertions isolées exécutées avec Node 22 (fixtures synthétiques, type stripping expérimental), PASS. Git apply --stat : lecture syntaxique du patch, pas application au checkout. Vitest, typecheck, hooks, navigateur, couverture, PostgreSQL et CI non exécutés. Le suivi privé persistant, ses API, ses migrations, ses preuves SQL et son interface restent à implémenter. Le lot complet n'est pas validé.
